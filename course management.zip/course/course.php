<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all courses
if ($method == 'GET') {
    $stmt = $db->prepare("SELECT * FROM course");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($courses);
}

// POST: Create new course with manual CourseID
elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    if (!isset($data->CourseID)) {
        http_response_code(400);
        echo json_encode(["message" => "CourseID is required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO course (CourseID, CourseName, CourseCode, Credits, DepartmentID)
        VALUES (?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->CourseID,
        $data->CourseName,
        $data->CourseCode,
        $data->Credits,
        $data->DepartmentID
    ])) {
        echo json_encode(["message" => "Course created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create course"]);
    }
}

// PUT: Update a course by CourseID
elseif ($method == 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $courseID = $params['CourseID'] ?? null;

    if (!$courseID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing CourseID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE course 
        SET CourseName = ?, CourseCode = ?, Credits = ?, DepartmentID = ?
        WHERE CourseID = ?
    ");

    if ($stmt->execute([
        $data->CourseName,
        $data->CourseCode,
        $data->Credits,
        $data->DepartmentID,
        $courseID
    ])) {
        echo json_encode(["message" => "Course updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update course"]);
    }
}

// DELETE: Delete a course by CourseID
elseif ($method == 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $courseID = $params['CourseID'] ?? null;

    if (!$courseID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing CourseID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM course WHERE CourseID = ?");
    if ($stmt->execute([$courseID])) {
        echo json_encode(["message" => "Course deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete course"]);
    }
}
