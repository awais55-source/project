<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all teaching assignments
if ($method == 'GET') {
    $stmt = $db->prepare("SELECT * FROM TeachingAssignment");
    $stmt->execute();
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($assignments);
}

// POST: Create new teaching assignment
elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->AssignmentID, $data->InstructorID, $data->CourseID, $data->Semester, $data->Year)) {
        http_response_code(400);
        echo json_encode(["message" => "Required fields are missing"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO TeachingAssignment (AssignmentID, InstructorID, CourseID, Semester, Year)
        VALUES (?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->AssignmentID,
        $data->InstructorID,
        $data->CourseID,
        $data->Semester,
        $data->Year
    ])) {
        echo json_encode(["message" => "Teaching assignment created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create teaching assignment"]);
    }
}

// PUT: Update teaching assignment
elseif ($method == 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $assignmentID = $params['AssignmentID'] ?? null;

    if (!$assignmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AssignmentID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE TeachingAssignment
        SET InstructorID = ?, CourseID = ?, Semester = ?, Year = ?
        WHERE AssignmentID = ?
    ");

    if ($stmt->execute([
        $data->InstructorID,
        $data->CourseID,
        $data->Semester,
        $data->Year,
        $assignmentID
    ])) {
        echo json_encode(["message" => "Teaching assignment updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update teaching assignment"]);
    }
}

// DELETE: Delete teaching assignment
elseif ($method == 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $assignmentID = $params['AssignmentID'] ?? null;

    if (!$assignmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing AssignmentID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM TeachingAssignment WHERE AssignmentID = ?");
    if ($stmt->execute([$assignmentID])) {
        echo json_encode(["message" => "Teaching assignment deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete teaching assignment"]);
    }
}
?>
