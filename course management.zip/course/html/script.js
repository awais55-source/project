document.addEventListener("DOMContentLoaded", function () {
  // Tab functionality
  const tabs = document.querySelectorAll(".nav-tabs a");
  const tabContents = document.querySelectorAll(".tab-content");

  tabs.forEach((tab) => {
    tab.addEventListener("click", function (e) {
      e.preventDefault();

      // Remove active class from all tabs and content
      tabs.forEach((t) => t.classList.remove("active"));
      tabContents.forEach((c) => c.classList.remove("active"));

      // Add active class to clicked tab and corresponding content
      this.classList.add("active");
      const target = this.getAttribute("href");
      document.querySelector(target).classList.add("active");
    });
  });

  // Form submission handlers
  const forms = {
    studentForm: "Student",
    enrollmentForm: "Enrollment",
    instructorForm: "Instructor",
    teachersForm: "Teaching Assignment",
    courseForm: "Course",
    departmentForm: "Department",
  };

  for (const [formId, formName] of Object.entries(forms)) {
    document.getElementById(formId).addEventListener("submit", function (e) {
      e.preventDefault();

      // Show success message
      const successMessage = document.createElement("div");
      successMessage.className = "success-message";
      successMessage.innerHTML = `
                <i class="fas fa-check-circle"></i>
                ${formName} information submitted successfully!
            `;

      this.parentNode.insertBefore(successMessage, this.nextSibling);

      // Remove message after 3 seconds
      setTimeout(() => {
        successMessage.remove();
      }, 3000);

      // Reset form
      this.reset();
    });
  }

  // Set first tab as active by default
  if (tabs.length > 0) {
    tabs[0].click();
  }
});

document.addEventListener("DOMContentLoaded", function () {
  const buttons = document.querySelectorAll("nav button");
  const sections = document.querySelectorAll(".form-section");

  buttons.forEach((button, index) => {
    button.addEventListener("click", () => {
      // Hide all sections
      sections.forEach((section) => (section.style.display = "none"));

      // Show the selected section
      sections[index].style.display = "block";

      // Optional: highlight active tab
      buttons.forEach((btn) => btn.classList.remove("active-tab"));
      button.classList.add("active-tab");
    });
  });

  // Show only the first section by default
  sections.forEach((section, index) => {
    section.style.display = index === 0 ? "block" : "none";
  });
});
