<?php
require_once 'db.php'; // Make sure this sets up and returns a PDO connection

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all departments
if ($method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM Department");
    $stmt->execute();
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($departments);
}

// POST: Create a new department
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (
        !isset($data->DepartmentID) ||
        !isset($data->DepartmentName) ||
        !isset($data->ChairPerson) ||
        !isset($data->OfficeLocation)
    ) {
        http_response_code(400);
        echo json_encode(["message" => "All fields are required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO Department (DepartmentID, DepartmentName, ChairPerson, OfficeLocation)
        VALUES (?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->DepartmentID,
        $data->DepartmentName,
        $data->ChairPerson,
        $data->OfficeLocation
    ])) {
        echo json_encode(["message" => "Department created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create department"]);
    }
}

// PUT: Update a department
elseif ($method === 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $departmentID = $params['DepartmentID'] ?? null;

    if (!$departmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing DepartmentID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE Department
        SET DepartmentName = ?, ChairPerson = ?, OfficeLocation = ?
        WHERE DepartmentID = ?
    ");

    if ($stmt->execute([
        $data->DepartmentName,
        $data->ChairPerson,
        $data->OfficeLocation,
        $departmentID
    ])) {
        echo json_encode(["message" => "Department updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update department"]);
    }
}

// DELETE: Delete a department
elseif ($method === 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $departmentID = $params['DepartmentID'] ?? null;

    if (!$departmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing DepartmentID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM Department WHERE DepartmentID = ?");
    if ($stmt->execute([$departmentID])) {
        echo json_encode(["message" => "Department deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete department"]);
    }
}

?>
