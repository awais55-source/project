<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

if ($method == 'GET') {
    $stmt = $db->prepare("SELECT * FROM Instructor");
    $stmt->execute();
    $instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($instructors);
}

elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->InstructorID)) {
        http_response_code(400);
        echo json_encode(["message" => "InstructorID is required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO Instructor (InstructorID, FirstName, LastName, DepartmentID)
        VALUES (?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->InstructorID,
        $data->FirstName,
        $data->LastName,
        $data->DepartmentID
    ])) {
        echo json_encode(["message" => "Instructor created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create instructor", "error" => $stmt->errorInfo()]);
    }
}

elseif ($method == 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $instructorID = $params['InstructorID'] ?? null;

    if (!$instructorID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing InstructorID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE Instructor
        SET FirstName = ?, LastName = ?, DepartmentID = ?
        WHERE InstructorID = ?
    ");

    if ($stmt->execute([
        $data->FirstName,
        $data->LastName,
        $data->DepartmentID,
        $instructorID
    ])) {
        echo json_encode(["message" => "Instructor updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update instructor", "error" => $stmt->errorInfo()]);
    }
}

elseif ($method == 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $instructorID = $params['InstructorID'] ?? null;

    if (!$instructorID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing InstructorID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM Instructor WHERE InstructorID = ?");
    if ($stmt->execute([$instructorID])) {
        echo json_encode(["message" => "Instructor deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete instructor", "error" => $stmt->errorInfo()]);
    }
}
?>
