use UniversityEnrollmentSystem;

CREATE TABLE Department (
    DepartmentID VARCHAR(10) PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL,
    ChairPerson VARCHAR(100) NOT NULL,
    OfficeLocation VARCHAR(100) NOT NULL
);

-- Student Table
CREATE TABLE Student (
    StudentID VARCHAR(10) PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Phone VARCHAR(20),
    Major VARCHAR(100)
);

-- Instructor Table
CREATE TABLE Instructor (
    InstructorID VARCHAR(10) PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DepartmentID VARCHAR(10),
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);

-- Course Table
CREATE TABLE Course (
    CourseID VARCHAR(10) PRIMARY KEY,
    CourseName VARCHAR(100) NOT NULL,
    CourseCode VARCHAR(20) NOT NULL,
    Credits INT CHECK (Credits BETWEEN 1 AND 6),
    DepartmentID VARCHAR(10),
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);

-- Enrollment Table
CREATE TABLE Enrollment (
    EnrollmentID VARCHAR(10) PRIMARY KEY,
    StudentID VARCHAR(10),
    CourseID VARCHAR(10),
    EnrollmentDate DATE NOT NULL,
    Grade VARCHAR(2),
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
);

-- Teaching Assignment Table
CREATE TABLE TeachingAssignment (
    AssignmentID VARCHAR(10) PRIMARY KEY,
    InstructorID VARCHAR(10),
    CourseID VARCHAR(10),
    Semester VARCHAR(20) NOT NULL,
    Year INT NOT NULL,
    FOREIGN KEY (InstructorID) REFERENCES Instructor(InstructorID),
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
);

-- ==============================
-- 2. INSERT SAMPLE DATA
-- ==============================

-- Departments
INSERT INTO Department VALUES
('D001', 'Computer Science', 'Dr. Usman', 'Room A-101'),
('D002', 'Mathematics', 'Dr. Zainab', 'Room B-202'),
('D003', 'Physics', 'Dr. Salman', 'Room C-303'),
('D004', 'English', 'Dr. Nida', 'Room D-101'),
('D005', 'Biology', 'Dr. Hassan', 'Room E-201');

-- Students
INSERT INTO Student VALUES
('S001', 'Ali', 'Khan', 'ali.khan@example.com', '03001234567', 'Computer Science'),
('S002', 'Sara', 'Raza', 'sara.raza@example.com', '03007894561', 'Mathematics'),
('S003', 'Bilal', 'Iqbal', 'bilal.iqbal@example.com', '03112233445', 'Physics'),
('S004', 'Zainab', 'Ali', 'zainab.ali@example.com', '03225678901', 'English'),
('S005', 'Hamza', 'Shah', 'hamza.shah@example.com', '03336547890', 'Biology');

-- Instructors
INSERT INTO Instructor VALUES
('I001', 'Fatima', 'Ahmed', 'D001'),
('I002', 'Noman', 'Tariq', 'D002'),
('I003', 'Hina', 'Qureshi', 'D003'),
('I004', 'Kamran', 'Malik', 'D004'),
('I005', 'Ayesha', 'Siddiqui', 'D005');

-- Courses
INSERT INTO Course VALUES
('C101', 'Data Structures', 'CS201', 3, 'D001'),
('C102', 'Calculus I', 'MATH101', 4, 'D002'),
('C103', 'Classical Mechanics', 'PHY101', 3, 'D003'),
('C104', 'English Literature', 'ENG201', 3, 'D004'),
('C105', 'Molecular Biology', 'BIO301', 4, 'D005');

-- Enrollments
INSERT INTO Enrollment VALUES
('E001', 'S001', 'C101', '2025-02-15', 'A'),
('E002', 'S002', 'C102', '2025-02-17', 'B'),
('E003', 'S003', 'C103', '2025-03-01', 'B'),
('E004', 'S004', 'C104', '2025-03-05', 'A'),
('E005', 'S005', 'C105', '2025-03-10', 'C');

-- Teaching Assignments
INSERT INTO TeachingAssignment VALUES
('TA001', 'I001', 'C101', 'Spring', 2025),
('TA002', 'I002', 'C102', 'Spring', 2025),
('TA003', 'I003', 'C103', 'Fall', 2025),
('TA004', 'I004', 'C104', 'Fall', 2025),
('TA005', 'I005', 'C105', 'Spring', 2025);
