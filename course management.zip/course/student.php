<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all Student
if ($method == 'GET') {
    $stmt = $db->prepare("SELECT * FROM student");
    $stmt->execute();
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($courses);
}

// POST: Create new Student with manual StudentID
elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    if (!isset($data->StudentID)) {
        http_response_code(400);
        echo json_encode(["message" => "StudentID is required"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO student (StudentID,FirstName ,LastName, Email,Phone, Major)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->StudentID,
        $data->FirstName,
        $data->LastName,
        $data->Email,
        $data->Phone,
        $data->Major
    

    ])) {
        echo json_encode(["message" => "Student created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create Student"]);
    }
}

// PUT: Update a Student by StudentID
elseif ($method == 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $StudentID = $params['StudentID'] ?? null;

    if (!$StudentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing StudentID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE student
        SET FirstName = ?, LastName = ?, Email= ?,  Phone = ? , Major= ? 
        WHERE StudentID = ?
    ");

    if ($stmt->execute([
        $data->FirstName,
        $data->LastName,
        $data->Email,
        $data->Phone,
        $data->Major,
        $data->StudentID

    ])) {
        echo json_encode(["message" => "Student updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update Student"]);
    }
}

// DELETE: Delete a Student by StudentID
elseif ($method == 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $StudentID = $params['StudentID'] ?? null;

    if (!$StudentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing StudentID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM student WHERE StudentID = ?");
    if ($stmt->execute([$StudentID])) {
        echo json_encode(["message" => "Student deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete Student"]);
    }
}
