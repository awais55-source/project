<?php
require_once 'db.php';

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$method = $_SERVER['REQUEST_METHOD'];
$db = (new Database())->getConnection();

// GET: Fetch all enrollments
if ($method == 'GET') {
    $stmt = $db->prepare("SELECT * FROM Enrollment");
    $stmt->execute();
    $enrollments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($enrollments);
}

// POST: Create new enrollment
elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->EnrollmentID, $data->StudentID, $data->CourseID, $data->EnrollmentDate)) {
        http_response_code(400);
        echo json_encode(["message" => "Required fields are missing"]);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO Enrollment (EnrollmentID, StudentID, CourseID, EnrollmentDate, Grade)
        VALUES (?, ?, ?, ?, ?)
    ");

    if ($stmt->execute([
        $data->EnrollmentID,
        $data->StudentID,
        $data->CourseID,
        $data->EnrollmentDate,
        $data->Grade ?? null
    ])) {
        echo json_encode(["message" => "Enrollment created successfully"]);
    } else {
        echo json_encode(["message" => "Failed to create enrollment"]);
    }
}

// PUT: Update enrollment
elseif ($method == 'PUT') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $enrollmentID = $params['EnrollmentID'] ?? null;

    if (!$enrollmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing EnrollmentID"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"));

    $stmt = $db->prepare("
        UPDATE Enrollment
        SET StudentID = ?, CourseID = ?, EnrollmentDate = ?, Grade = ?
        WHERE EnrollmentID = ?
    ");

    if ($stmt->execute([
        $data->StudentID,
        $data->CourseID,
        $data->EnrollmentDate,
        $data->Grade,
        $enrollmentID
    ])) {
        echo json_encode(["message" => "Enrollment updated successfully"]);
    } else {
        echo json_encode(["message" => "Failed to update enrollment"]);
    }
}

// DELETE: Delete enrollment
elseif ($method == 'DELETE') {
    parse_str($_SERVER['QUERY_STRING'], $params);
    $enrollmentID = $params['EnrollmentID'] ?? null;

    if (!$enrollmentID) {
        http_response_code(400);
        echo json_encode(["message" => "Missing EnrollmentID"]);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM Enrollment WHERE EnrollmentID = ?");
    if ($stmt->execute([$enrollmentID])) {
        echo json_encode(["message" => "Enrollment deleted successfully"]);
    } else {
        echo json_encode(["message" => "Failed to delete enrollment"]);
    }
}
?>
